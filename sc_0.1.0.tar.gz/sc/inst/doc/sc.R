### R code from vignette source 'sc.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: sc.Rnw:47-49
###################################################
library(EBImage)
library(sc)


###################################################
### code chunk number 2: sc.Rnw:57-61
###################################################
imagePath <- system.file("images", "sample-color.png", package="EBImage")
img <- readImage(imagePath)
dim(img)
display(img)


###################################################
### code chunk number 3: sc.Rnw:73-75
###################################################
energy_map <- sc_mark_leastCSeam(imagePath)$energy_map
display(energy_map)


###################################################
### code chunk number 4: sc.Rnw:93-95
###################################################
seam_image <- sc_mark_leastCSeam(imagePath)$seam_image
display(seam_image)


###################################################
### code chunk number 5: sc.Rnw:115-118
###################################################
increased_img <- sc_increase(imagePath, 10, 10)$increased_img
display(increased_img)
dim(increased_img)


###################################################
### code chunk number 6: sc.Rnw:147-151
###################################################
result <- sc_reduce(imagePath, ncols = 8, nrows = 12)
attributes(result)
dim(result$img_reduced)
display(result$img_reduced)


###################################################
### code chunk number 7: sc.Rnw:159-162
###################################################
result <- sc_reduce(imagePath, ncols = 18)$img_reduced
dim(result)
display(result)


###################################################
### code chunk number 8: sc.Rnw:187-191
###################################################
result <- sc_increase(imagePath, ncols = 10, nrows = 10)
attributes(result)
dim(result$increased_img)
display(result$increased_img)


###################################################
### code chunk number 9: sc.Rnw:208-211
###################################################
result <- sc_mark_leastCSeam(imagePath)
attributes(result)
display(result$seam_image)


